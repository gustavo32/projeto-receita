install.packages("NLP")
install.packages("tm")
library("NLP")
library("tm")

receitas <- read.csv("~/Documentos/Semestre_6/Oficina/RStudio/receitas.csv", stringsAsFactors = F)
ingredientes <- tolower(receitas$ingredientes)
ingredientes <- removeNumbers(ingredientes)
ingredientes <- removePunctuation(ingredientes, preserve_intra_word_dashes = TRUE)
ingredientes <- removeWords(ingredientes, c(stopwords("portuguese"),
  "sopa", "picada", "picado", "picados", "picadas", "unidade", "unidades", "dente", "dentes", "esmagados", 
  "esmagadas","esmagado", "esmagada", "gosto", "kg", "kilogramas", "preferência","preferencia", "gr","grama", "g",
  "gramas", "chá", "cha", "rodelas", "socados", "socadas", "magro", "magra", "ralado", "ralada", "raladas", 
  "ralados", "lata", "latas", "ml", "gema","gemas", "fresco", "fresca", "frescos", "frescas", "xícara", 
  "xícaras", "xicara", "xicaras", "suco", "sucos", "pau","paus", "mistura", "misturas","litro","litros", 
  "colheres","colher", "folhas","folha","moídas", "moídos", "moída", "moido", "moidas", "moidos", "moida", 
  "moido", "desidratado", "desidratada", "copo", "copos", "média", "médias", "médio", "médios","media", 
  "medias", "medio", "medios", "maduro", "madura", "maduros", "maduras", "grande", "grandes", "pequeno", "peq",
  "pequena", "pequenos", "pequenas", "grão", "grãos", "grao", "graos", "picadinho", "picadinha", "picadinhos", 
  "picadinhas", "amassado", "amassada", "amassadas", "amassados", "tablete", "tabletes", "dissolvido", 
  "dissolvidos", "dissolvida", "dissolvidas", "diluído", "diluída", "diluídos", "diluídas", "diluido", 
  "diluida", "diluidos", "diluidas", "desnatado", "desnatada", "desnatados", "desnatadas", "sobremesa", 
  "sobremesas", "espremido", "espremida", "espremidos", "espremidas", "esprimido", "esprimida", "esprimidos", 
  "esprimidas", "cabeça", "cabeças", "pele", "peles", "cubo", "cubos", "cubinho", "cubinhos", "pitada", "pitadas",
  "aproximadamente", "poupa", "poupas", "seco", "seca", "secos", "secas", "molhado", "molhada", "molhados", 
  "molhadas", "refogado", "refogados", "refogar", "caixa", "caixas", "marinho", "marinhos", "gelado", "gelada", "gelados",
  "geladas", "integral", "integrais", "fervente", "ferventes", "envelope", "finamente", "raso", "rasa", "rasos",
  "rasas", "tempero", "temperos", "pó", "pós", "po", "pos", "maço", "maços", "cozido", "cozida", "cozidos",
  "cozidas", "passarinho", "passarinhos", "fatiado", "fatiados", "pedaço", "pedaços", "bem", "limpos", "limpo", 
  "cortado", "cortada", "cortados", "cortadas", "anéis", "anél", "anel", "aneis", "massa", "massas", "socado", 
  "socada", "socados", "socadas", "cheia", "cheio", "cheias", "cheios", "grego", "tirado", "tirada", "tirados", 
  "tiradas", "assado", "assada", "assados", "assadas", "caixinha", "caixinhas", "café", "cafés", "cafe", "cafes", 
  "ccafé", "frio", "fria", "frios", "frias", "opcional", "fina", "fino", "finas", "finas", "pacote", "pacotes", 
  "melhorar", "tom", "tons", "avermelhado", "alimentício", "alimenticio", "descascado", "descascada", "descascados", 
  "descascadas", "pacote", "pacotes", "dificuldade", "dificuldades", "fácil", "fáceis", "facil", "faceis", 
  "derretido", "derretida", "derretidos", "derretidas", "cálice", "calice", "cálices", "calices", "condimento", 
  "condimentos", "base", "bases", "dijon", "passata", "lembrando", "salgado", "ingredientes", "ingrediente", 
  "metade", "metades", "integra", "integras", "casca", "cascas", "confit", "dl", "ramo", "ramos", "hora", "horas", 
  "necessário", "necessários", "necessario", "necessarios", "tipo", "bola", "bolas", "acompanhar", "escolha", "ale", 
  "clara", "miolo", "pausterizar", "pauterizados", "pauterizada", "pausterizadas", "pauterizado", "vidro", "vidros", 
  "blog", "receita", "receitas", "melhor", "pior", "é", "marca", "natural", "life", "pessoa", "pessoas", "bom", "mal",
  "diversos", "seguir", "fatia", "fatias", "grosso", "grossa", "grossos", "grossas", "americano", "aqui",
  "ali", "gota", "gotas", "faca", "facas", "básica", "básico", "básicas", "básicos", "basica", "basico", "basicas", 
  "basicos", "resto", "leve", "raíz", "raízes", "raiz", "raizes", "raspa", "raspas", "semente", "sementes", 
  "grosseiramente", "morna", "morno", "mornas", "mornos", "sabor", "pote", "potes", "outro", "outra", "outros", "outras",
  "frutas", "congelada", "congelado", "congeladas", "congelados", "forte", "fortes", "fraco", "fracos", "molhar", "ficam",
  "ficar", "dose", "doses", "suficiente", "suficientes", "bons", "maus", "falta", "faltar", "use", "usar", "copinho",
  "copinhos", "plástico", "plásticos", "plastico", "plasticos", "batido", "batida", "batidos", "batidas", "neve", "neves",
  "peneira", "peneiras", "peneiradas", "peneirados", "peneirada", "peneirado", "tirar", "fervido", "fervida", "fervidos",
  "fervidas", "barra", "barras", "coberto", "coberta", "cobertos", "cobertas","cobertura","coberturas", "meia", "quente",
  "quentes", "triturada", "triturado", "trituradas", "triturados", "polvinhar", "decorar", "light", "firme", "firmes",
  "temperatura","temperaturas",  "ambiente","ambientes", "meio", "sumo", "reservar", "colh", "inteira", "inteiro",
  "inteiras", "inteiros", "caroço", "caroços", "conservar", "conserva", "conservas", "torrado", "torrados"
))
ingredientes <- stripWhitespace(ingredientes)


